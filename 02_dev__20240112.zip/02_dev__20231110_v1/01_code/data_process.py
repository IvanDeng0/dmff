# -*- coding: utf-8 -*-
"""
Created on Fri Jul 14 14:57:54 2023

@author: 86150
"""
import csv
import datetime
import re
import os,json
import numpy as np
import math
import torch
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
from torch.utils.data import random_split
import matplotlib.pyplot as plt
import torch.optim.lr_scheduler
import baseline_mlp
import sys
#sys.path.append('D:/master/multi/mycode/dmf/gp_test_frame/')
#D:\intern\sip_qos\diff_models
sys.path.append(os.path.dirname(os.path.abspath(__file__))+"/diff_models")
#sys.path.append('./diff_models')
from diff_models import dmodel
from diff_models import architec
import matplotlib.pyplot as plt
import seaborn as sns
import argparse

sns.set()
sns.set_theme(style='white')


dataLoc = os.path.dirname(os.path.abspath(__file__))+"/../02_data/"



#input_feature = ['qos','valid','rwType','BL',]
#output_feature = ['trsNum','trsNumOl','latAvgOl','bwOl']
#get start time
starttime = datetime.datetime.now()

'''
BATCH_SIZE = 64
LR = 1e-2
WEIGHT_DECAY = 1e-4
ALPHA_LR = 1e-2
ALPHA_WD = 1e-4
NUM_NEURON = 20#神经元个数
NUM_INTER_NODE = 20#中间节点个数
RATIO = 0.5#训练集占比
RANDOM_SEED = 0#随机数种子
N_ITER = 12#训练循环数
'''

def preds_process(preds,threshold):
    for i in range(len(preds)):
        for j in range(len(preds[0])):
            if preds[i,j] <= threshold: #predict threshold setup, error predict for evaluation about the model selection
                preds[i,j] = 0
    return preds

def min_error(preds, y): 
    e = torch.abs(preds-y)
    result = []
    for i in range(len(e)):
        temp = float('inf')
        for j in range(len(e[0])):
            if 0 < e[i,j] < temp:
                temp = e[i,j]
        result.append(temp)
    
    return result

def input_process(feature, featurename,qos,NUM_SIPS):
    if len(re.findall('dst', featurename)) > 0:
        temp = []
        for i in range(NUM_SIPS):
            x = feature[i]   
            if len(x) == 0:
                temp.append(0)
            else:
                if x in qos:
                    temp.append(qos[x])
                else:
                    qos[x] = len(qos)
                    temp.append(qos[x])
                    
        return temp
    elif featurename == 'valid':
        return [float(i) for i in feature]
    elif featurename == 'rwType':
        temp = []
        for i in range(NUM_SIPS):
            x = feature[i]
            if len(x) == 0:
                if i == 0:
                    #temp.append(rw_dict[feature[1]])
                    #temp.append(feature[1] or rw_dict.get(feature[2]) or rw_dict.get(feature[3]))
                    temp.append(int(x))
                else:
                    temp.append(temp[i-1])
            else:
                temp.append(int(x))
        return temp
    elif featurename == 'BL':
        temp = []
        for i in range(NUM_SIPS):
            x = feature[i]
            if x == '0':
                temp.append(0)
                continue
            if len(x) == 0:
                if i == 0:
                    #temp.append(math.log(int(feature[1]),2))
                    for j in range(1,NUM_SIPS):
                        if len(feature[j]) != 0:
                            break
                    temp.append(math.log(int(feature[j]),2))
                else:
                    temp.append(temp[i-1])
            else:
                temp.append(math.log(int(feature[i]),2))
        return temp
    else:
        return [float(i) for i in feature]
     
def output_process(label,NUM_SIPS):
    temp = []
    for i in range(NUM_SIPS):
        x = label[i]
        if len(x) == 0:
            temp.append(0)
        else:
            temp.append(float(x))
    return temp

def data_process(dataset,path,i_line,o_line,NUM_SIPS,OUTPUT_IDX):
    inputs = []
    outputs = []
    input_hashs = {}
    output_hashs = {}
    qos = {'0':0}
    for data in dataset:
        data = path +'/' + data
        with open(data,'r') as f:
            reader=csv.reader(f)
            result=np.array(list(reader))
            Feature_name = result[0]
            for i in range(i_line):
                input_hashs[i] = Feature_name[i+2]
            for i in range(o_line-1, o_line):
                output_hashs[i] = Feature_name[i+2+i_line]
            #print(result)
            output_feature = result[1:,3+i_line:3+i_line+o_line]#need to aline with output field, such as olBw
            input_feature = result[1:,2:2+i_line]
            #print(input_feature)
            #print('-------------------------')
            #print(input_feature[18:21,:])
            Numcases = (len(result)-1)//NUM_SIPS
            for i in range(Numcases):
                temp = []
                for k in range(i_line):
                    mid_temp = []
                    for j in range(NUM_SIPS*i, NUM_SIPS+NUM_SIPS*i):
                        mid_temp.append(input_feature[j,k])
                    mid_temp = input_process(mid_temp, input_hashs[k],qos,NUM_SIPS) 
                    temp.extend(mid_temp)
                inputs.append(temp)
            
            #
            '''
            for i in range(len(out_feature)):
                result[1][i] = float(result[1][i])/float(result[0][i]) 
            '''
            for i in range(Numcases):
                temp = []
                for k in range(OUTPUT_IDX-1, OUTPUT_IDX):
                    mid_temp = []
                    for j in range(NUM_SIPS*i, NUM_SIPS+NUM_SIPS*i):
                        mid_temp.append(output_feature[j,k])
                    mid_temp = output_process(mid_temp,NUM_SIPS)
                    temp.extend(mid_temp)
                    
                outputs.append(temp)
            
    return inputs, outputs
                



def train_mulnode(inputs, outputs, data_path, i_line, o_line, ratio,seeds, n_iters, STEP, DROPOUT):
    torch.manual_seed(seeds)
    total_size = len((inputs))
    print('total_size = ',total_size)
    train_size = int(ratio*total_size)
    test_size = total_size - train_size
    
    in_feature = len(inputs[0])//i_line
    out_feature = len(outputs[0])//o_line
    #print('in_feature',in_feature)
    #print('out_feature',out_feature)
    inputs = torch.tensor(inputs)
    outputs = torch.tensor(outputs)
    #print(inputs[0])
    #print(outputs[0])
    data = TensorDataset(inputs, outputs)
    train_data, test_data = random_split(data, [train_size, test_size])
    
    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE)
    
    criterion = nn.MSELoss()
    model = dmodel.Network(NUM_INTER_NODE, i_line,criterion,in_feature,out_feature,NUM_NEURON, DROPOUT)
    model.train()
    # weight decay for network 1 is 1e-4
    optimizer = torch.optim.Adam(model.parameters(), LR, weight_decay=WEIGHT_DECAY)
    #optimizer = torch.optim.NAdam(model.parameters(), lr=0.01, betas=(0.9, 0.999), eps=1e-08, weight_decay=0, momentum_decay=0.004)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, n_iters)
    archtect = architec.Architect(model , ALPHA_LR, ALPHA_WD)
    
    #----training stage
    stepCnt=0;
    for i in range(n_iters):
        print('-------------------',i,'-----------------')
                   
        for j in range(50): 
            for step,(inputs,target) in enumerate(train_loader):
                optimizer.zero_grad()         
                logits=model(inputs)
                loss=criterion(logits,target)
                loss.backward()
                stepCnt+=1
                if stepCnt%100 == 0: 
                    print('loss =',loss)
                optimizer.step()
                if step%STEP==0:
                    archtect.step(inputs, target,0)  
        scheduler.step()
        midtime = datetime.datetime.now()
        tmp = (midtime - starttime).seconds #minutes
        duration = float(tmp)/60.0
        print ("iteration round:%4d finished, time elapse : %.2f mins\n" % (i, duration))

    #----training results error analyzation
    model.eval()
    save_path = data_path +'/../train_model_params'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    torch.save(model.alphas,save_path+'/alphas.pth') 
    torch.save(model.state_dict(), save_path + '/diffmodel_parameters.pth')
    '''
    with torch.no_grad():
        for step,(batch_x,batch_y) in enumerate(test_loader):
        #temp=model1(batch_x)
            preds=model(batch_x)
            threshold = torch.mean(preds)/5
            threshold = threshold.item()
            preds = preds_process(preds, threshold)
            result = torch.mean(torch.abs(preds-batch_y))
            #preds = preds_process(preds)
            #print('preds',preds[:5])
            #print('y',batch_y[:5])
            #error=torch.sqrt(torch.mean(torch.pow(preds-batch_y,2)))
            #max_result = torch.max(torch.abs(preds-batch_y),dim=1).values
            #min_result = torch.tensor(min_error(preds, batch_y))
    #diff_result =  max_result-min_result
    '''
    return 0
    
    
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    #parser.add_argument('-p', type=str, default = "dummy",    help='输入文件路径')
    parser.add_argument('-c', type=str, default = "dummy",    help='输入训练推理数据路径')
    
    args = parser.parse_args()
    if args.c == "dummy":
        #data_path = dataLoc+"/"+args.c
        data_path = dataLoc + '/' + 'WR'
        #用windows运行
    else:
        data_path = dataLoc +'/'+ args.c
    if os.path.exists(data_path + '/config.json'):
        with open(data_path + '/config.json','r', encoding='utf-8') as f:
            configs = json.load(f)
        BATCH_SIZE = configs['BATCH_SIZE']
        LR = configs['LR']
        WEIGHT_DECAY = configs['WEIGHT_DECAY']
        ALPHA_LR = configs['ALPHA_LR']
        ALPHA_WD = configs['ALPHA_WD']
        NUM_NEURON = configs['NUM_NEURON']#神经元个数
        NUM_INTER_NODE = configs['NUM_INTER_NODE']#中间节点个数
        RATIO = configs['RATIO']#训练集占比
        RANDOM_SEED = configs['RANDOM_SEED']#随机数种子
        N_ITER = configs['N_ITER']#训练循环数
        TOTAL_INPUT = configs['TOTAL_INPUT']
        TOTAL_OUTPUT = configs['TOTAL_OUTPUT']
        ACTUAL_OUTPUT = configs['ACTUAL_OUTPUT']
        NUM_SIPS = configs['NUM_SIPS']
        OUTPUT_IDX = configs['OUTPUT_IDX']
        STEP = configs['STEP']
        DROPOUT = configs['DROPOUT']
    else:
        BATCH_SIZE = 64
        LR = 1e-2
        WEIGHT_DECAY = 2e-3
        ALPHA_LR = 1e-2
        ALPHA_WD = 2e-3
        NUM_NEURON = 20#神经元个数
        NUM_INTER_NODE = 5#中间节点个数
        RATIO = 1#训练集占比
        RANDOM_SEED = 0#随机数种子
        N_ITER = 12#训练循环数
        TOTAL_INPUT = 35
        TOTAL_OUTPUT = 3
        ACTUAL_OUTPUT = 1
        NUM_SIPS = 16
        OUTPUT_IDX = 3
        STEP = 10
        DROPOUT = 0.1
        configs = dict()
        configs['BATCH_SIZE'] = BATCH_SIZE
        configs['LR'] = LR
        configs['WEIGHT_DECAY'] = WEIGHT_DECAY
        configs['ALPHA_LR'] = ALPHA_LR
        configs['ALPHA_WD'] = ALPHA_WD
        configs['NUM_NEURON'] = NUM_NEURON
        configs['NUM_INTER_NODE'] = NUM_INTER_NODE
        configs['RATIO'] = RATIO
        configs['RANDOM_SEED'] = RANDOM_SEED
        configs['N_ITER'] = N_ITER
        configs['TOTAL_INPUT'] = TOTAL_INPUT
        configs['TOTAL_OUTPUT'] = TOTAL_OUTPUT
        configs['ACTUAL_OUTPUT'] = ACTUAL_OUTPUT
        configs['NUM_SIPS'] = NUM_SIPS
        configs['OUTPUT_IDX'] = OUTPUT_IDX
        configs['STEP'] = STEP
        configs['DROPOUT'] = DROPOUT
        with open(data_path + '/config.json', 'w') as f:
            json.dump(configs, f)
            
        
    data_path = data_path  + '/train_data' 
    dataset = []
    for filename in os.listdir(data_path):
        dataset.append(filename)
    inputs, outputs = data_process(dataset,data_path, TOTAL_INPUT, TOTAL_OUTPUT, NUM_SIPS,OUTPUT_IDX)
    train_mulnode(inputs, outputs, data_path, TOTAL_INPUT, ACTUAL_OUTPUT, RATIO,RANDOM_SEED, N_ITER, STEP, DROPOUT)
    
'''
for s in range(3):
    result = train_mulnode(inputs, outputs, 4, 1, ratio,s, 40)
    maxs.append(result)
  
with open('result/'+str(ratio)+'result'+'.csv', 'w',encoding='UTF8', newline='') as f:
    writer = csv.writer(f)
    for i in range(3):
        writer.writerow(maxs[i])
    
'''
#train_mlp(inputs, outputs, 0.8, 100)
#print(len(inputs))
#print('------------------------')
#print(outputs)
                
            
        
