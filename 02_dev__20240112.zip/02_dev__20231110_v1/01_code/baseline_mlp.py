# -*- coding: utf-8 -*-
"""
Created on Mon Jul 17 11:20:31 2023

@author: 86150
"""

hidden_layers=50
hidden_size=40
Epochs=100
import torch.nn as nn
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader



class mlp(nn.Module):
    
    def __init__(self,in_feature,out_feature,hidden_size):
        super().__init__()
        
        self.layer1=nn.Linear(in_feature, hidden_size)
        layers=[]
        for i in range(hidden_layers):
            layers.append(nn.Linear(hidden_size, hidden_size))

        self.layer2=nn.ModuleList(layers)
        self.layer3=nn.Linear(hidden_size, out_feature)
        
        
    def forward(self,x):
        x=self.layer1(x)
        x=F.relu(x)
        for i,layer in enumerate(self.layer2):
            x=layer(x)
            x=F.relu(x)
        x=self.layer3(x)
        
        return x