# -*- coding: utf-8 -*-
"""
Created on Fri Jul 14 14:57:54 2023

@author: 86150
"""
import csv
import datetime
import re
import os
import numpy as np
import math
import torch
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
import torch.distributed as dist
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
from torch.utils.data import random_split
import matplotlib.pyplot as plt
import torch.optim.lr_scheduler
import baseline_mlp
import sys
#sys.path.append('D:/master/multi/mycode/dmf/gp_test_frame/')
#D:\intern\sip_qos\diff_models
sys.path.append(os.path.dirname(os.path.abspath(__file__))+"/diff_models")
#sys.path.append('./diff_models')
from diff_models import dmodel
from diff_models import architec
import matplotlib.pyplot as plt
import seaborn as sns
import argparse

sns.set()
sns.set_theme(style='white')


dataLoc = os.path.dirname(os.path.abspath(__file__))+"/../02_data/"


dataset = ['harvest_sip_rw_CBF_BL01_20230713.csv','harvest_sip_rw_CBF_BL04_20230713.csv',\
           'harvest_sip_rw_CBF_BL08_20230713.csv','harvest_sip_rw_CBF_BL16_20230713.csv']
    
dataset2 = ['harvest_sip_qos_rw_GDDR_BL04_20230816.csv']

dataset3 = ['SKU0_1VF1VG_harvest_qos_WR_20230921.csv']

dataset4 = ['perf_rpt_Scorpio_simulation_SKU0_1VF1VG_SIP_RD_CBF_qos.csv','perf_rpt_Scorpio_simulation_SKU0_1VF1VG_SIP_RW_CBF_qos.csv',\
            'perf_rpt_Scorpio_simulation_SKU0_1VF1VG_SIP_WR_CBF_qos.csv']

#input_feature = ['qos','valid','rwType','BL',]
#output_feature = ['trsNum','trsNumOl','latAvgOl','bwOl']
#get start time
starttime = datetime.datetime.now()

BATCH_SIZE = 64
LR = 1e-2
WEIGHT_DECAY = 1e-4
ALPHA_LR = 1e-2
ALPHA_WD = 1e-4
NUM_NEURON = 20#神经元个数
NUM_INTER_NODE = 20#中间节点个数
RATIO = 0.5#训练集占比
RANDOM_SEED = 0#随机数种子
N_ITER = 12#训练循环数


def preds_process(preds,threshold):
    for i in range(len(preds)):
        for j in range(len(preds[0])):
            if preds[i,j] <= threshold: #predict threshold setup, error predict for evaluation about the model selection
                preds[i,j] = 0
    return preds

def min_error(preds, y): 
    e = torch.abs(preds-y)
    result = []
    for i in range(len(e)):
        temp = float('inf')
        for j in range(len(e[0])):
            if 0 < e[i,j] < temp:
                temp = e[i,j]
        result.append(temp)
    
    return result

def input_process(feature, featurename,qos):
    if len(re.findall('dst', featurename)) > 0:
        temp = []
        for i in range(16):
            x = feature[i]   
            if len(x) == 0:
                temp.append(0)
            else:
                if x in qos:
                    temp.append(qos[x])
                else:
                    qos[x] = len(qos)
                    temp.append(qos[x])
                    
        return temp
    elif featurename == 'valid':
        return [float(i) for i in feature]
    elif featurename == 'rwType':
        temp = []
        for i in range(16):
            x = feature[i]
            if len(x) == 0:
                if i == 0:
                    #temp.append(rw_dict[feature[1]])
                    #temp.append(feature[1] or rw_dict.get(feature[2]) or rw_dict.get(feature[3]))
                    temp.append(int(x))
                else:
                    temp.append(temp[i-1])
            else:
                temp.append(int(x))
        return temp
    elif featurename == 'BL':
        temp = []
        for i in range(16):
            x = feature[i]
            if x == '0':
                temp.append(0)
                continue
            if len(x) == 0:
                if i == 0:
                    #temp.append(math.log(int(feature[1]),2))
                    for j in range(1,16):
                        if len(feature[j]) != 0:
                            break
                    temp.append(math.log(int(feature[j]),2))
                else:
                    temp.append(temp[i-1])
            else:
                temp.append(math.log(int(feature[i]),2))
        return temp
    else:
        return [float(i) for i in feature]
     
def output_process(label):
    temp = []
    for i in range(16):
        x = label[i]
        if len(x) == 0:
            temp.append(0)
        else:
            temp.append(float(x))
    return temp

def data_process(dataset,path,i_line,o_line):
    inputs = []
    outputs = []
    input_hashs = {}
    output_hashs = {}
    qos = {'0':0}
    for data in dataset:
        data = path +'/' + data
        with open(data,'r') as f:
            reader=csv.reader(f)
            result=np.array(list(reader))
            Feature_name = result[0]
            for i in range(i_line):
                input_hashs[i] = Feature_name[i+2]
            for i in range(o_line-1, o_line):
                output_hashs[i] = Feature_name[i+2+i_line]
            #print(result)
            output_feature = result[1:,3+i_line:3+i_line+o_line]#need to aline with output field, such as olBw
            input_feature = result[1:,2:2+i_line]
            #print(input_feature)
            #print('-------------------------')
            #print(input_feature[18:21,:])
            Numcases = (len(result)-1)//16
            for i in range(Numcases):
                temp = []
                for k in range(i_line):
                    mid_temp = []
                    for j in range(16*i, 16+16*i):
                        mid_temp.append(input_feature[j,k])
                    mid_temp = input_process(mid_temp, input_hashs[k],qos) 
                    temp.extend(mid_temp)
                inputs.append(temp)
            
            #
            '''
            for i in range(len(out_feature)):
                result[1][i] = float(result[1][i])/float(result[0][i]) 
            '''
            for i in range(Numcases):
                temp = []
                for k in range(o_line-1, o_line):
                    mid_temp = []
                    for j in range(16*i, 16+16*i):
                        mid_temp.append(output_feature[j,k])
                    mid_temp = output_process(mid_temp)
                    temp.extend(mid_temp)
                    
                outputs.append(temp)
            
    return inputs, outputs
                
def train_mlp(inputs, outputs, ratio, n_iters):
    total_size = len((inputs))
    train_size = int(ratio*total_size)
    test_size = total_size - train_size
    
    in_feature = len(inputs[0])
    out_feature = len(outputs[0])
    
    inputs = torch.tensor(inputs)
    outputs = torch.tensor(outputs)
    
    data = TensorDataset(inputs, outputs)
    train_data, test_data = random_split(data, [train_size, test_size])
    
    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE)
    test_loader = DataLoader(test_data, batch_size = test_size)
    
    model = baseline_mlp.mlp(in_feature, out_feature, 50)
    optimizer = torch.optim.Adam(model.parameters(), LR, weight_decay=WEIGHT_DECAY)
    scheduler=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, n_iters)
    criterion=nn.MSELoss()
    
    model.train()
    for i in range(n_iters):
        scheduler.step()           
        for step,(inputs,target) in enumerate(train_loader):
            optimizer.zero_grad()         
            logits=model(inputs)
            loss=criterion(logits,target)
            print('loss = ', loss)
            loss.backward()
            optimizer.step()
    
    model.eval()
    with torch.no_grad():
        for step,(batch_x,batch_y) in enumerate(test_loader):
            preds=model(batch_x)
            error=torch.sqrt(torch.mean(torch.pow(preds-batch_y,2)))
            
    print('error=',error)
   



def train_mulnode(inputs, outputs, data_path, i_line, o_line, ratio,seeds, n_iters):
    torch.manual_seed(seeds)
    total_size = len((inputs))
    print('total_size = ',total_size)
    train_size = int(ratio*total_size)
    test_size = total_size - train_size
    
    in_feature = len(inputs[0])//i_line
    out_feature = len(outputs[0])//o_line
    #print('in_feature',in_feature)
    #print('out_feature',out_feature)
    inputs = torch.tensor(inputs)
    outputs = torch.tensor(outputs)
    #print(inputs[0])
    #print(outputs[0])
    data = TensorDataset(inputs, outputs)
    train_data, test_data = random_split(data, [train_size, test_size])
    
    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE)
    test_loader = DataLoader(test_data, batch_size = test_size)
    
    criterion = nn.MSELoss()
    
    model = dmodel.Network(NUM_INTER_NODE, i_line,criterion,in_feature,out_feature,NUM_NEURON)
    model.train()
    # weight decay for network 1 is 1e-4
    optimizer = torch.optim.Adam(model.parameters(), LR, weight_decay=WEIGHT_DECAY)
    #optimizer = torch.optim.NAdam(model.parameters(), lr=0.01, betas=(0.9, 0.999), eps=1e-08, weight_decay=0, momentum_decay=0.004)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, n_iters)
    archtect = architec.Architect(model , ALPHA_LR, ALPHA_WD)
    
    #----training stage
    stepCnt=0;
    for i in range(n_iters):
        print('-------------------',i,'-----------------')
        scheduler.step()           
        for j in range(50): 
            for step,(inputs,target) in enumerate(train_loader):
                optimizer.zero_grad()         
                logits=model(inputs)
                loss=criterion(logits,target)
                loss.backward()
                stepCnt+=1
                if stepCnt%100 == 0: 
                    print('loss =',loss)
                optimizer.step()
                if step%10==0:
                    archtect.step(inputs, target,0)  
        midtime = datetime.datetime.now()
        tmp = (midtime - starttime).seconds #minutes
        duration = float(tmp)/60.0
        print ("iteration round:%4d finished, time elapse : %.2f mins\n" % (i, duration))

    #----training results error analyzation
    model.eval()
    save_path = data_path + '/train_model_params'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    torch.save(model.alphas,save_path+'/alphas.pth') 
    torch.save(model.state_dict(), save_path + '/diffmodel_parameters.pth')
    with torch.no_grad():
        for step,(batch_x,batch_y) in enumerate(test_loader):
        #temp=model1(batch_x)
            preds=model(batch_x)
            threshold = torch.mean(preds)/5
            threshold = threshold.item()
            preds = preds_process(preds, threshold)
            result = torch.mean(torch.abs(preds-batch_y))
            #preds = preds_process(preds)
            #print('preds',preds[:5])
            #print('y',batch_y[:5])
            #error=torch.sqrt(torch.mean(torch.pow(preds-batch_y,2)))
            #max_result = torch.max(torch.abs(preds-batch_y),dim=1).values
            #min_result = torch.tensor(min_error(preds, batch_y))
    #diff_result =  max_result-min_result
    return result
    
def train_mulnode_dist(inputs, outputs, data_path, i_line, o_line, ratio,seeds, n_iters):
    torch.manual_seed(seeds)
    total_size = len((inputs))
    print('total_size = ',total_size)
    train_size = int(ratio*total_size)
    test_size = total_size - train_size
    
    in_feature = len(inputs[0])//i_line
    out_feature = len(outputs[0])//o_line
    #print('in_feature',in_feature)
    #print('out_feature',out_feature)
    inputs = torch.tensor(inputs)
    outputs = torch.tensor(outputs)
    #print(inputs[0])
    #print(outputs[0])
    data = TensorDataset(inputs, outputs)
    train_data, test_data = random_split(data, [train_size, test_size])
    train_sampler = torch.utils.data.distributed.DistributedSampler(train_data)
    kwargs = {'num_workers': 5, 'pin_memory': True}
    
    train_loader = DataLoader(train_data, batch_size=BATCH_SIZE, shuffle = False ,sampler = train_sampler, **kwargs)
    test_loader = DataLoader(test_data, batch_size = test_size)
    
    criterion = nn.MSELoss()
    
    model = dmodel.Network(NUM_INTER_NODE, i_line,criterion,in_feature,out_feature,NUM_NEURON)
    model = torch.nn.parallel.DistributedDataParallelCPU(model)
    model.train()
    # weight decay for network 1 is 1e-4
    optimizer = torch.optim.Adam(model.parameters(), LR, weight_decay=WEIGHT_DECAY)
    #optimizer = torch.optim.NAdam(model.parameters(), lr=0.01, betas=(0.9, 0.999), eps=1e-08, weight_decay=0, momentum_decay=0.004)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, n_iters)
    archtect = architec.Architect(model , ALPHA_LR, ALPHA_WD)
    
    #----training stage
    stepCnt=0;
    for i in range(n_iters):
        print('-------------------',i,'-----------------')
        scheduler.step()           
        for j in range(50): 
            for step,(inputs,target) in enumerate(train_loader):
                optimizer.zero_grad()         
                logits=model(inputs)
                loss=criterion(logits,target)
                loss.backward()
                stepCnt+=1
                if stepCnt%100 == 0: 
                    print('loss =',loss)
                optimizer.step()
                if step%10==0:
                    archtect.step(inputs, target,0)  
        midtime = datetime.datetime.now()
        tmp = (midtime - starttime).seconds #minutes
        duration = float(tmp)/60.0
        print ("iteration round:%4d finished, time elapse : %.2f mins\n" % (i, duration))

    #----training results error analyzation
    model.eval()
    save_path = data_path + '/train_model_params'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    torch.save(model.alphas,save_path+'/alphas.pth') 
    torch.save(model.state_dict(), save_path + '/diffmodel_parameters.pth')
    with torch.no_grad():
        for step,(batch_x,batch_y) in enumerate(test_loader):
        #temp=model1(batch_x)
            preds=model(batch_x)
            threshold = torch.mean(preds)/5
            threshold = threshold.item()
            preds = preds_process(preds, threshold)
            result = torch.mean(torch.abs(preds-batch_y))
            #preds = preds_process(preds)
            #print('preds',preds[:5])
            #print('y',batch_y[:5])
            #error=torch.sqrt(torch.mean(torch.pow(preds-batch_y,2)))
            #max_result = torch.max(torch.abs(preds-batch_y),dim=1).values
            #min_result = torch.tensor(min_error(preds, batch_y))
    #diff_result =  max_result-min_result
    return result
    
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', type=str, default = "dummy",    help='输入文件路径')
    parser.add_argument('-c', type=str, default = "dummy",    help='输入训练推理数据路径')
    args = parser.parse_args()
    
    if args.p == "dummy":
        #data_path = dataLoc+"/"+args.c
        data_path = dataLoc + '/' + 'CBF'
        #用windows运行
    else:
        data_path = args.p+"/"+args.c
    #初始化分布式
    envs = os.environ
    world = envs.get('WORLD_SIZE') if envs.get('WORLD_SIZE') else 1
    data_path = data_path + '/train_data'   
    inputs, outputs = data_process(dataset4,data_path, 35, 3)
    if world > 1:
        dist.init_process_group("gloo")
        rank = dist.get_rank()
        dist.init_process_group(init_method='tcp', backend="gloo", world_size=world, rank=rank,
                                group_name="pytorch_test")

        result = train_mulnode_dist(inputs, outputs, data_path, 35, 1, RATIO,RANDOM_SEED, N_ITER)
    else:
        result = train_mulnode(inputs, outputs, data_path, 35, 1, RATIO,RANDOM_SEED, N_ITER)
    print(result)
'''
for s in range(3):
    result = train_mulnode(inputs, outputs, 4, 1, ratio,s, 40)
    maxs.append(result)
  
with open('result/'+str(ratio)+'result'+'.csv', 'w',encoding='UTF8', newline='') as f:
    writer = csv.writer(f)
    for i in range(3):
        writer.writerow(maxs[i])
    
'''
#train_mlp(inputs, outputs, 0.8, 100)
#print(len(inputs))
#print('------------------------')
#print(outputs)
                
            
        
