# -*- coding: utf-8 -*-
"""
Created on Sat Mar 26 16:46:37 2022

@author: Lenovo
"""

import numpy as np
import torch
import os
import sys
import csv
import scipy.io as scio
sys.path.append('D:/master/multi/mycode/dmf/gp_test_frame/')
import logging
import torch.nn as nn
import torch.utils
import torch.nn.functional as F
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
import matplotlib.pyplot as plt
import torch.optim.lr_scheduler
import random
import h5py
import copy
import pandas as pd
import datetime
#from Exp.tools.exp_tools import \
#    print_metrics, calculate_metrics, get_model_class_name, write_data2csv, integrate_exp_info, fix_seed
#from Exp.exp_5functions_benchmark.benchmark_setting import generate_data, BOREHOLE, BRANIN, CURRIN, HART, PARK,TL1,\
    #TL2,TL3,TL4,TL5,TL6,TL7,TL8,TL9,TL10

from torch.autograd import *
from model import *
from architec import Architect



def concat_on_new_last_dim(arrays):
    arrays = [_array.reshape(*_array.shape, 1) for _array in arrays]
    return np.concatenate(arrays, axis=-1)


def write_data2csv(tgt_dir,tgt_name,head_info,data_info):
    if not os.path.exists(tgt_dir):
        os.makedirs(tgt_dir)
    data_frame=pd.DataFrame(columns=head_info)

    for col,col_name in enumerate(head_info):
        data_frame[col_name]=np.asarray(data_info[col])
    csv_path=os.path.join(tgt_dir,tgt_name)
    if os.path.exists(csv_path):
        data_frame.to_csv(csv_path,mode='a',encoding='utf-8',index=False,header=None)
    else:
        data_frame.to_csv(csv_path,mode='a',encoding='utf-8',index=False)



LR=0.01
length=1000

low_train_size_1=32
low_train_size_2=20
high_train_sizes=[4,8,16,32]
#high_train_size=4
device=torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
#currin function
def test(dataset,seed,high_train_size,weightdecay,n_iters,sub_epoch_w,sub_epoch_a,n_iters_2,lr1,lr2,lr3):
    torch.cuda.empty_cache() 
    data = scio.loadmat('data/'+dataset)
    '''
    xl0=data['xtr']
    yl1=data['Ytr'][0][0]
    yl2=data['Ytr'][0][1]
    #yh0=data['Ytr'][0][2]
    yh0=yl2

    xhte=data['xte']
    ylte1=[data['Yte'][0][0][i].flatten() for i in range(len(xhte))]
    ylte2=[data['Yte'][0][1][i].flatten() for i in range(len(xhte))]
    #yhte=[data['Yte'][0][2][i].flatten() for i in range(len(xhte))]
    yhte=ylte2
    '''
    #real_data
    '''
    x=data['X']
    yl=data['Y'][0][0]
    yh=data['Y'][0][-1]
    length=int(0.6*len(x))
    '''
    #SOFC
    x=data['X']
    yl=concat_on_new_last_dim([data['Y1'][0][0], data['Y2'][0][0]])
    yh=concat_on_new_last_dim([data['Y1'][0][1], data['Y2'][0][1]])
    length=int(0.6*len(x))
    
    print(len(yl[0]))
    print(len(yl[0][0])) 
    
    print(len(yh[0]))
    print(len(yh[0][0]))                        
    xl0=x[:length]
    yl1=yl[:length]
    yh0=yh[:length]

    xhte0=x[length:]
    yhte0=yh[length:]

    random.seed(seed)
    low_train_set_1=random.sample(range(len(yl1)), low_train_size_1)
    low_train_set_2=random.sample(range(len(yl1)), low_train_size_2)
    high_train_set=random.sample(range(len(yl1)), high_train_size)
    
    if len(xhte0)>128:
        test_set=random.sample(range(len(xhte0)),128)
    else:
        test_set=range(len(xhte0))

    xltr,yltr_1_net1,yltr_1_net2,yltr_2_net2,yltr_2_net3,yhtr_net3=[],[],[],[],[],[]
    xhtr=[]
    xhte,yhte=[],[]
    '''
    for i in low_train_set_1:
        xltr.append(xl0[i].flatten())
        yltr_1_net1.append(yl1[i].flatten())


    for i in high_train_set:
        xhtr.append(xl0[i].flatten())
        yltr_2_net3.append(yl2[i].flatten())
        yhtr_net3.append(yh0[i].flatten())
    '''
    for i in low_train_set_1:
        xltr.append(xl0[i])
        yltr_1_net1.append(yl1[i].flatten())


    for i in high_train_set:
        xhtr.append(xl0[i])
        #yltr_2_net3.append(yl2[i])
        yhtr_net3.append(yh0[i].flatten())

    for i in test_set:
        xhte.append(xhte0[i])
        yhte.append(yhte0[i].flatten())
    
    xltr=torch.tensor(xltr,dtype=torch.float32,device=device)
    xhtr=torch.tensor(xhtr,dtype=torch.float32,device=device)
    yltr_1_net1=torch.tensor(yltr_1_net1,dtype=torch.float32,device=device)
    #yltr_2_net3=torch.tensor(yltr_2_net3,dtype=torch.float32,device=device)
    yhtr_net3=torch.tensor(yhtr_net3,dtype=torch.float32,device=device)

    
#test case
    #ylte1=torch.tensor(ylte1,dtype=torch.float32,device=device)
    #ylte2=torch.tensor(ylte2,dtype=torch.float32,device=device)

    xhte=torch.tensor(xhte,dtype=torch.float32,device=device)
    yhte=torch.tensor(yhte,dtype=torch.float32,device=device)

    in_feature=len(xl0[0])
    out_feature1=len(yltr_1_net1[0])
    out_feature2=len(yhtr_net3[0])


    criterion=nn.MSELoss()
    
    #optimizer2 = torch.optim.Adam(model2.parameters(), LR, weight_decay=weightdecay)
    
    dataset1=TensorDataset(xltr,yltr_1_net1)
    train_loader1=DataLoader(dataset1,batch_size=10,shuffle=False)
    
    dataset3 = TensorDataset(xhtr,yhtr_net3)
    train_loader3=DataLoader(dataset3,batch_size=8,shuffle=False)
    
    
    testset=TensorDataset(xhte,yhte)
    test_loader=DataLoader(testset,batch_size=128,shuffle=False)

    #scheduler2=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer2, n_iters_2)
    
    
    #first network
    
    model1=Network(2, criterion,in_feature,out_feature1,20).to(device)
    model1.train()
    # weight decay for network 1 is 1e-4
    optimizer1 = torch.optim.Adam(model1.parameters(), LR, weight_decay=1e-4)
    scheduler1=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer1, n_iters)
    archtect1=Architect(model1,1e-2,1e-4)
    
    
    for i in range(n_iters):
        print('-------------------',i,'-----------------')
        scheduler1.step()           
        for j in range(sub_epoch_w): 
            for step,(inputs,target) in enumerate(train_loader1):
                optimizer1.zero_grad()         
                logits=model1(inputs)
                loss=criterion(logits,target)
                loss.backward()
                optimizer1.step()
                if step%sub_epoch_a==0:
                    archtect1.step(inputs, target,0)
                #print('loss1=',loss)
                
    
    
    model2=copy.deepcopy(model1)
    model2.train()
    linear_output=nn.Linear(out_feature1, out_feature2).to(device)
    params=[{'params':model2.parameters(),'lr':lr1},
            {'params':linear_output.parameters(),'lr':lr2}]
    optimizer2 = torch.optim.Adam(params, weight_decay=weightdecay)
    scheduler2=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer2, n_iters_2)
    archtect2=Architect(model2,lr3,weightdecay)
    
    '''
    model3=copy.deepcopy(model1)
    optimizer3 = torch.optim.Adam(model3.parameters(), LR, weight_decay=weightdecay)
    scheduler3=torch.optim.lr_scheduler.CosineAnnealingLR(optimizer3, n_iters)
    archtect3=Architect(model3)
    ''' 
    
    print('------first network training finished------')
    errors=[]
    model1.eval()
    for i in range(n_iters_2):
        model2.train()
        print('-------------------',i,'-----------------')
        scheduler2.step()
        for j in range(sub_epoch_w):    
            for step,(inputs,target) in enumerate(train_loader3):
                optimizer2.zero_grad()  
                logits=model2(inputs)
                logits=linear_output(logits)
                loss=criterion(logits,target)
                loss.backward()
                optimizer2.step()
                if step%sub_epoch_a==0:
                    archtect2.step(inputs, target,1,linear_output)
        model2.eval()
        with torch.no_grad():
            for step,(batch_x,batch_y) in enumerate(test_loader):
                temp=model2(batch_x)
                preds=linear_output(temp)
                error=torch.sqrt(torch.mean(torch.pow(preds-batch_y,2)))
        errors.append(error)
    

    model1.eval()    
    model2.eval()
    with torch.no_grad():
        for step,(batch_x,batch_y) in enumerate(test_loader):
        #temp=model1(batch_x)
            temp=model2(batch_x)
            preds=linear_output(temp)
            #preds2=model3(batch_x)
            error=torch.sqrt(torch.mean(torch.pow(preds-batch_y,2)))
        '''
        model1=model1.cpu()
        model2=model2.cpu()
        linear_output=linear_output.cpu()
        preds=preds.cpu()
        '''
       
    print('error=',error)
    return min(errors)
    '''
    data_info_list = [[seed],[error.cpu().detach().numpy()],[high_train_size]]
    target_dir='./results/'
    write_data2csv(tgt_dir=os.path.join(target_dir,f"{dataset}/"),tgt_name="dmf{}.csv".format(seed),head_info=('seed','rmse','train_sample'),data_info=data_info_list)
    '''
    


#weightdecays=[1e-2,1e-3,1e-4]
#n_iterss=[4,6,8,10] 10
#n_iters_2s=[4,6,8] 6
#sub_epoch_as=[1,2,3,4,5,6,7,8,9,10] 3
#sub_epoch_ws=[40,50] 50
lr1=[1e-5,1e-6]
lr2=[1e-2,1e-3,1e-4]
lr3=[1e-4,1e-5,1e-6]
weightdecays=[1e-4,1e-5,1e-6]
#wd1=[1e-2,1e-3,1e-4]
#wd2=[1e-2,1e-3,1e-4]

n_iter_2s=[20]

seed=[0,1,2,3,4]
#run_times=10
#1e-4,1e-2,1e-5
#path='./results/'

z=[]
y=[]
L=['SOFC_MF.mat']
for j in range(len(seed)):
    for i in range(len(L)):
        for o in range(2):
            for p in range(3):
                for q in range(3):
                    for r in range(len(n_iter_2s)):
                        A={}
                        A['lr1']=lr1[o]
                        A['lr2']=lr2[p]
                        A['lr3']=lr3[q]
                        error=test(L[i], seed[j],32 ,1e-4, 10, 50, 1,n_iter_2s[r],lr1[o],lr2[p],lr3[q])
                        A['error']=error
                        z.append(A)
                        y.append(error.detach().numpy())
                        print(y)
    f=open('logg{}.txt'.format(seed[j]),mode='w')
    f.write(str(z))
    f.write('\n')
    f.write(str(min(y)))
    f.close()

print(z)



'''
for i in range(len(L)):
    for j in range(len(seed)):
        for k in range(len(high_train_sizes)):
            test(L[i], seed[j],high_train_sizes[k] ,1e-4, 10, 50, 1,25,1e-6,1e-2,1e-4)

current_time=datetime.datetime.now()
print(current_time)
'''
