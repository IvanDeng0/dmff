# -*- coding: utf-8 -*-
"""
Created on Sat Mar 26 16:17:11 2022

@author: Lenovo
"""

import torch
import numpy as np
import torch.nn as nn
from torch.autograd import *





class Architect(object):
    def __init__(self,model,LR,wd):
        self.model=model
        self.optimizer=torch.optim.Adam(self.model.alphas_parameters(),lr=LR,weight_decay=wd)
        
    def _backward_step(self,inputs,target,output_layer=None):
        loss=self.model._loss(inputs,target)
        #print('loss2=',loss)
        loss.backward()
    def _backward_step2(self,inputs,target,output_layer=None):
        loss=self.model._loss2(inputs,target,output_layer)
        loss.backward()
        
        
    def step(self,inputs,target,flag,output_layer=None):
        if flag==0:
            self.optimizer.zero_grad()
            self._backward_step(inputs, target)
            self.optimizer.step()
        else:
            self.optimizer.zero_grad()
            self._backward_step2(inputs, target,output_layer)
            self.optimizer.step()

