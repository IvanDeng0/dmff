# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 11:02:47 2022

@author: Lenovo
"""

from collections import namedtuple

Genotype = namedtuple('Genotype', 'normal')


PRIMITIVES = [
    'none',
    'deep',
    'shaw',
    'high',
    'lina',
]
