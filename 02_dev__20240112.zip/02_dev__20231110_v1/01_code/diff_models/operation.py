# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 10:42:22 2022

@author: Lenovo
"""


from torch import nn

OPS={'none':lambda in_feature,channel: Zero(),
     'deep':lambda in_feature,channel: model_deep(in_feature,channel),
     'shaw':lambda in_feature,channel: model_shallow(in_feature,channel),
     'high':lambda in_feature,channel: model_high(in_feature,channel),
     'lina':lambda in_feature,channel: model_linear(in_feature,channel)
     }

class model_deep(nn.Module):
    def __init__(self,in_feature,channel):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_feature,channel),
            nn.ReLU(),
            nn.Linear(channel,channel),
            nn.ReLU(),
            nn.Linear(channel, channel),
            nn.ReLU(),
            nn.Linear(channel, in_feature),
            )
    def forward(self,x):
        x=self.layer(x)
        return x
    
    
class model_shallow(nn.Module):
    def __init__(self,in_feature,channel):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_feature, channel),
            nn.ReLU(),
            nn.Linear(channel, in_feature),
            )
    def forward(self,x):
        x=self.layer(x)
        return x
    
class model_high(nn.Module):
    def __init__(self,in_feature,channel):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_feature, 2*channel),
            nn.Linear(2*channel, in_feature),
            )
    def forward(self,x):
        x=self.layer(x)
        return x   
    

class model_linear(nn.Module):
    def __init__(self,in_feature,channel):
        super().__init__()
        self.layer = nn.Sequential(
            nn.Linear(in_feature, channel),
            nn.Linear(channel, in_feature),
            )
    def forward(self,x):
        x=self.layer(x)
        return x
    
    
class Zero(nn.Module):
    def ___init__(self):
        super().__init__()
        
    def forward(self,x):
        x=x.mul(0.)
        return x
        

