# -*- coding: utf-8 -*-
"""
Created on Fri Mar 25 11:30:31 2022

@author: Lenovo
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import operation
#from operation import *
from genotype import PRIMITIVES
from torch.autograd import Variable
from genotype import Genotype



class MixedOP(nn.Module):
    def __init__(self,in_feature,channel,DROPOUT):
        super().__init__()
        self.dropout = nn.Dropout(DROPOUT)
        self._ops=nn.ModuleList()
        for primitive in PRIMITIVES:
            op=operation.OPS[primitive](in_feature,channel)
            self._ops.append(op)
    
    def forward(self,x,weights):
        res = sum(w * op(x) for w, op in zip(weights, self._ops))
        return self.dropout(res)
    
    
class Network(nn.Module):
    def __init__(self,steps,i_line,criterion,in_feature,out_feature,channel, DROPOUT):
        super().__init__()
        self._steps=steps
        self.in_feature = in_feature
        self.i_line = i_line
        self._ops=nn.ModuleList()
        self._initialize_alpha()
        
        self._criterion=criterion
        #self._dropout=nn.Dropout(0.1)
        self._output=nn.Linear(in_feature, out_feature)
        for i in range(self._steps):
            for j in range(i+self.i_line):
                op=MixedOP(in_feature,channel,DROPOUT)
                self._ops.append(op)
    
    def forward(self,inputs):
        weights=F.softmax(self.alphas,dim=-1)
        #多输入改这里
        states=[]
        for i in range(self.i_line):
            states.append(inputs[:,i*self.in_feature:self.in_feature*(i+1)])
        offset=0
        harvest = states[0]
        mask = torch.ones(harvest.size())  - harvest
        mask = mask.bool()
        x = sum(states)
        for i in range(self._steps):
            s = sum(self._ops[offset+j](h, weights[offset+j]) for j, h in enumerate(states))
            offset+=len(states)
            states.append(s+harvest)
            #states.append(nn.BatchNorm1d(self.in_feature)(s+harvest))
            #states.append(nn.LayerNorm(self.in_feature)(s+harvest))
        out=states[-1]
        logits=self._output(out)
        #print('mask',mask)
        logits.masked_fill_(mask, 0)
        #logits=self.output_pro(logits) 
        return logits
    '''
    def output_pro(self,x):
        x = x.detach().numpy()
        for i in range(len(x)):
            for j in range(len(x[0])):
                if abs(x[i,j]) <= 5:
                    x[i,j] = 0
        return x
    '''
    def _initialize_alpha(self):
        k= sum(1 for i in range(self._steps) for n in range(self.i_line+i))
        num_ops=len(PRIMITIVES)
        
        self.alphas = Variable(1e-3*torch.randn(k, num_ops), requires_grad=True)
        self._alphas_parameters=[self.alphas]
        
    def _loss(self,inputs,target):
        logits=self(inputs)
        return self._criterion(logits,target)
    def _loss2(self,inputs,target,output_layer):
        logits=self(inputs)
        logits=output_layer(logits)
        return self._criterion(logits,target)
        
    def alphas_parameters(self):
        return self._alphas_parameters
            
    def genotype(self):
      def _parse(weights):
        gene = []
        n = 1
        start = 0
        for i in range(self._steps):
          end = start + n
          W = weights[start:end].copy()
          # 找出来前驱节点的哪两个边的权重最大
          edges = sorted(range(i + 1), key=lambda x: -max(W[x][k] for k in range(len(W[x])) if k != PRIMITIVES.index('none')))[:2]#sorted：对可迭代对象进行排序，key是用来进行比较的元素
                                                              # range(i + 2)表示x取0，1，到i+2 x也就是前驱节点的序号 ，所以W[x]就是这个前驱节点的所有权重[α0,α1,α2,...,α7]
                                                              # max(W[x][k] for k in range(len(W[x])) if k != PRIMITIVES.index('none')) 就是把操作不是NONE的α放到一个list里，得到最大值
                                                              # sorted 就是把每个前驱节点对应的权重最大的值进行逆序排序，然后选出来top2
    
          # 把这两条边对应的最大权重的操作找到
          for j in edges:
            k_best = None
            for k in range(len(W[j])):
              if k != PRIMITIVES.index('none'):
                if k_best is None or W[j][k] > W[j][k_best]:
                  k_best = k
            gene.append((PRIMITIVES[k_best], j)) #把(操作，前驱节点序号)放到list gene中，[('sep_conv_3x3', 1),...,]
          start = end
          n += 1
        return gene
    
      gene = _parse(F.softmax(self.alphas, dim=-1).data.cpu().numpy()) #得到normal cell 的最后选出来的结果
      
      #concat = range(2+self._steps-self._multiplier, self._steps+2) #[2,3,4,5] 表示对节点2，3，4，5 concat
      genotype = Genotype(
        normal=gene
      )
      return genotype


class MulNetwork(nn.Module):
    def __init__(self,in_feature,out_feature,channel):
        super().__init__()
        self._in_feature=in_feature
        self._channel=channel
        self._output=nn.Linear(in_feature, out_feature)
    def compiles(self,genotype):
        op_names, indices = zip(*genotype.normal)
        net=nn.ModuleList()
        for name,index in zip(op_names,indices):
            op=operation.OPS[name](self._in_feature,self._channel)
            net+=[op]
        self._ops=net
    def forward(self,x):
        s=self._ops[0](x)
        h1=self._ops[1](x)
        h2=self._ops[2](s)
        out=h1+h2
        out=self._output(out)
        return out
