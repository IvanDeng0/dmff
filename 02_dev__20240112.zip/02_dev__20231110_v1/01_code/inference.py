# -*- coding: utf-8 -*-
"""
Created on Fri Sep 22 11:27:58 2023

@author: 86150
"""

import torch
import re, os
import torch.nn as nn
import torch.utils
import csv
import numpy as np
import math
import torch.nn.functional as F
from torch.utils.data import TensorDataset
from torch.utils.data import DataLoader
from torch.utils.data import random_split
import matplotlib.pyplot as plt
import sys
import argparse
import json
import re
#sys.path.append('D:/master/multi/mycode/dmf/gp_test_frame/')
#D:\intern\sip_qos\diff_models
#sys.path.append('D:/intern/sip_qos/diff_models')
#sys.path.append('./diff_models')
sys.path.append(os.path.dirname(os.path.abspath(__file__))+"/diff_models")

from diff_models import dmodel
from diff_models import architec

dataLoc = os.path.dirname(os.path.abspath(__file__))+"/../02_data"

'''
def preds_process(preds,threshold):
    for i in range(len(preds)):
        for j in range(len(preds[0])):
            if preds[i,j] <= threshold: #predict threshold setup, error predict for evaluation about the model selection
                preds[i,j] = 0
    return preds
'''
def input_process(feature, featurename,qos,NUM_SIPS):
    if len(re.findall('dst', featurename)) > 0:
        temp = []
        for i in range(NUM_SIPS):
            x = feature[i]   
            if len(x) == 0:
                temp.append(0)
            else:
                if x in qos:
                    temp.append(qos[x])
                else:
                    qos[x] = len(qos)
                    temp.append(qos[x])
                    
        return temp
    elif featurename == 'valid':
        return [float(i) for i in feature]
    elif featurename == 'rwType':
        temp = []
        for i in range(NUM_SIPS):
            x = feature[i]
            if len(x) == 0:
                if i == 0:
                    #temp.append(rw_dict[feature[1]])
                    #temp.append(feature[1] or rw_dict.get(feature[2]) or rw_dict.get(feature[3]))
                    temp.append(int(x))
                else:
                    temp.append(temp[i-1])
            else:
                temp.append(int(x))
        return temp
    elif featurename == 'BL':
        temp = []
        for i in range(NUM_SIPS):
            x = feature[i]
            if x == '0':
                temp.append(0)
                continue
            if len(x) == 0:
                if i == 0:
                    #temp.append(math.log(int(feature[1]),2))
                    for j in range(1,NUM_SIPS):
                        if len(feature[j]) != 0:
                            break
                    temp.append(math.log(int(feature[j]),2))
                else:
                    temp.append(temp[i-1])
            else:
                temp.append(math.log(int(feature[i]),2))
        return temp
    else:
        return [float(i) for i in feature]

def data_process(dataset,mem,i_line,NUM_SIPS):
    inputs = []
    input_hashs = {}
    qos = {}
    qos['0'] = 0
    for data in dataset:
        data = mem +'/' + data
        with open(data,'r') as f:
            reader=csv.reader(f)
            result=np.array(list(reader))
            Feature_name = result[0]
            for i in range(i_line):
                input_hashs[i] = Feature_name[i+2]
            
            #print(result)
            input_feature = result[1:,2:2+i_line]
            
            Numcases = (len(result)-1)//NUM_SIPS
            for i in range(Numcases):
                temp = []
                for k in range(i_line):
                    mid_temp = []
                    for j in range(NUM_SIPS*i, NUM_SIPS+NUM_SIPS*i):
                        mid_temp.append(input_feature[j,k])
                    mid_temp = input_process(mid_temp, input_hashs[k], qos,NUM_SIPS) 
                    
                    temp.extend(mid_temp)
                inputs.append(temp)
    return inputs


def infer(inputs, i_line, model_path, alpha_path ,in_feature, out_feature, DROPOUT):
    in_feature = len(inputs[0])//i_line
    criterion = nn.MSELoss()
    inputs = torch.tensor(inputs)
    alpha = torch.load(alpha_path)
    alpha = alpha.detach()
    #print('last_alpha',alpha)
    model = dmodel.Network(NUM_INTER_NODE, i_line,criterion,in_feature,out_feature,NUM_NEURON, DROPOUT)
    model.eval()
    model.load_state_dict(torch.load(model_path), strict=True)
    model.alphas = alpha
    #print('current_alphas',model.alphas)
    
    '''
    with open('./params/test_model/model_dict.txt','w') as f:
        for param_tensor in model.state_dict():
            x = str(param_tensor) + "\t" + str(model.state_dict()[param_tensor])
            f.write(x)
            f.write('\n')
    '''
    with torch.no_grad():
        preds = model(inputs)
    #threshold = torch.mean(preds)/5
    #threshold = threshold.item()
    #preds = preds_process(preds, threshold)
    #print(preds)
    #print(len(preds))
    #print(len(preds[0]))
    return preds


def write_save(dataset, path, file_name, preds):
    for i in range(len(dataset)):
        data = path +'/' + dataset[i]
        with open(data,'r') as f:
            reader=csv.reader(f)
            result= list(reader)
        
        pre_result = path  + '/' + dataset[i][:-4] + '__' + file_name
        length = len(result)
        preds = preds.flatten()
        preds = preds.tolist()
        result[0].append('Prediction')
        for i in range(1, length):
            result[i].append(preds[i-1])
        with open(pre_result, 'w',encoding='UTF8', newline='') as f:
            writer = csv.writer(f)
            for i in range(length):
                writer.writerow(result[i])

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', type=str, default = "dummy",    help='输入训练推理数据路径')
    args = parser.parse_args()
    
    if args.c == "dummy":
        data_path = dataLoc + '/' + 'WR'
        #用windows运行
    else:
        data_path = dataLoc +'/'+ args.c
    configs = dict()
    with open(data_path + '/config.json','r', encoding='utf-8') as f:
        configs = json.load(f)
    
    NUM_NEURON = configs['NUM_NEURON']#神经元个数
    NUM_INTER_NODE = configs['NUM_INTER_NODE']#中间节点个数
    i_line = configs['TOTAL_INPUT']
    NUM_SIPS = configs['NUM_SIPS']
    DROPOUT = configs['DROPOUT']
    save_path = data_path + '/train_model_params/'
    data_path = data_path + '/infer_data'
    
    dataset = []
    for filename in os.listdir(data_path):
        if len(re.findall('infer_result', filename)) == 0:
            dataset.append(filename)
    inputs = data_process(dataset,data_path, i_line,NUM_SIPS)
    
    preds = infer(inputs, i_line, save_path +'diffmodel_parameters.pth', save_path + 'alphas.pth',in_feature=NUM_SIPS,out_feature=NUM_SIPS, DROPOUT=DROPOUT)
    write_save(dataset, data_path, 'infer_result.csv', preds)

#python3 data_process.py -p /Users/ben/00_MyWork/00_MyEnflameWorks/00_PerfAi/02_dev/02_data/WR
#python3 inference.py -p /Users/ben/00_MyWork/00_MyEnflameWorks/00_PerfAi/02_dev/02_data/WR
